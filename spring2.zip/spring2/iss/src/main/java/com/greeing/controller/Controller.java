package com.greeing.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@RequestMapping(value = "/greeting", method = RequestMethod.POST, produces = "text/xml")
	public ResponseEntity<String> getGreeting(@RequestBody String name) 
	{	
		logger.info("Input Name : " + name);
		String response =  "Hello " + name;
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}
	
}
