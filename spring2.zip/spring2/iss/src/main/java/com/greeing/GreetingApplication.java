package com.greeing;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/* Don't Change the Directory of this, otherwise it will not work */

//Same as @Configuration @EnableAutoConfiguration @ComponentScan combined
@SpringBootApplication(scanBasePackages={"com.greeing.*"})

public class GreetingApplication implements CommandLineRunner {

	private static Logger logger = LoggerFactory.getLogger(GreetingApplication.class);
	
	public static void main(String[] args) {
		System.out.println("Starting Greeting Application"); 
		
		/* Don't put any log statement before this, since logback is not initialized yet */
		try{
			SpringApplication.run(GreetingApplication.class, args);
		}catch(Exception e){
			System.out.println("Failed to start Greeting Application");
			logger.error("Failed to start Greeting Application", e);
			e.printStackTrace();
			System.exit(1);
			throw e;
		}
		System.setProperty("sun.java2d.cmm", "sun.java2d.cmm.kcms.KcmsServiceProvider");
		logger.info("Started Greeting Application");
		System.out.println("Started Greeting Application");
	}
	
	@Override
    public void run(String... args) throws Exception {	
    }
}
